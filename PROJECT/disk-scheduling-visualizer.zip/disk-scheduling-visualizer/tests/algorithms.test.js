// Run with:  npm test
// Plain Node test runner - no extra libraries needed.
import test from 'node:test';
import assert from 'node:assert/strict';
import { fcfs, sstf, scan, cscan, runAllAlgorithms } from '../src/algorithms/index.js';
import { validateInput } from '../src/utils/validation.js';

const example = (direction = 'right') => ({
  requests: [98, 183, 37, 122, 14, 124, 65, 67],
  initialHead: 53,
  minCylinder: 0,
  maxCylinder: 199,
  direction,
});

// ---------------------------------------------------------------- textbook example
test('FCFS on the textbook example', () => {
  const r = fcfs(example());
  assert.deepEqual(r.serviceSequence, [98, 183, 37, 122, 14, 124, 65, 67]);
  assert.deepEqual(r.distances, [45, 85, 146, 85, 108, 110, 59, 2]);
  assert.equal(r.totalMovement, 640);
  assert.equal(r.averageMovement, 80);
  assert.equal(r.requestsServiced, 8);
});

test('SSTF on the textbook example', () => {
  const r = sstf(example());
  assert.deepEqual(r.serviceSequence, [65, 67, 37, 14, 98, 122, 124, 183]);
  assert.equal(r.totalMovement, 236);
});

test('SCAN going right reaches 199 then reverses', () => {
  const r = scan(example('right'));
  assert.deepEqual(r.path, [53, 65, 67, 98, 122, 124, 183, 199, 37, 14]);
  assert.deepEqual(r.serviceSequence, [65, 67, 98, 122, 124, 183, 37, 14]);
  assert.equal(r.totalMovement, 331); // (199-53) + (199-14)
  assert.equal(r.steps.filter((s) => s.kind === 'boundary').length, 1);
});

test('SCAN going left reaches 0 then reverses', () => {
  const r = scan(example('left'));
  assert.deepEqual(r.path, [53, 37, 14, 0, 65, 67, 98, 122, 124, 183]);
  assert.equal(r.totalMovement, 236); // (53-0) + (183-0)
});

test('C-SCAN going right wraps from 199 to 0', () => {
  const r = cscan(example('right'));
  assert.deepEqual(r.path, [53, 65, 67, 98, 122, 124, 183, 199, 0, 14, 37]);
  assert.deepEqual(r.serviceSequence, [65, 67, 98, 122, 124, 183, 14, 37]);
  assert.equal(r.totalMovement, 382); // 146 + 199 (wrap) + 37
  assert.equal(r.steps.filter((s) => s.kind === 'wrap').length, 1);
});

test('C-SCAN going left wraps from 0 to 199', () => {
  const r = cscan(example('left'));
  assert.deepEqual(r.path, [53, 37, 14, 0, 199, 183, 124, 122, 98, 67, 65]);
  assert.equal(r.totalMovement, 386); // 53 + 199 (wrap) + (199-65)
});

// ---------------------------------------------------------------- edge cases
test('SSTF breaks distance ties towards the lower cylinder', () => {
  const r = sstf({ requests: [60, 40], initialHead: 50, minCylinder: 0, maxCylinder: 99, direction: 'right' });
  assert.deepEqual(r.serviceSequence, [40, 60]);
  assert.equal(r.totalMovement, 30);
});

test('C-SCAN skips the wrap when nothing is left behind the head', () => {
  const r = cscan({ requests: [20, 30], initialHead: 10, minCylinder: 0, maxCylinder: 199, direction: 'right' });
  assert.deepEqual(r.path, [10, 20, 30, 199]);
  assert.equal(r.totalMovement, 189);
});

test('Head already on the boundary adds no zero-length boundary step', () => {
  const r = scan({ requests: [10, 50], initialHead: 199, minCylinder: 0, maxCylinder: 199, direction: 'right' });
  assert.deepEqual(r.path, [199, 50, 10]);
  assert.equal(r.totalMovement, 189);
});

test('Request at the head position and duplicate requests are serviced', () => {
  for (const algorithm of [fcfs, sstf, scan, cscan]) {
    const r = algorithm({ requests: [50, 50, 70], initialHead: 50, minCylinder: 0, maxCylinder: 99, direction: 'right' });
    assert.deepEqual([...r.serviceSequence].sort((a, b) => a - b), [50, 50, 70]);
    assert.equal(r.requestsServiced, 3);
  }
});

test('Single request works for every algorithm and direction', () => {
  for (const direction of ['left', 'right']) {
    for (const r of runAllAlgorithms({ requests: [5], initialHead: 5, minCylinder: 0, maxCylinder: 10, direction })) {
      assert.deepEqual(r.serviceSequence, [5]);
    }
  }
});

// ---------------------------------------------------------------- invariants on random input
test('Random inputs: invariants hold for all algorithms and directions', () => {
  let seed = 12345;
  const rand = (n) => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed % n;
  };
  for (let round = 0; round < 300; round++) {
    const min = rand(20) - 10;
    const max = min + 1 + rand(200);
    const count = 1 + rand(15);
    const requests = Array.from({ length: count }, () => min + rand(max - min + 1));
    const head = min + rand(max - min + 1);
    for (const direction of ['left', 'right']) {
      const input = { requests, initialHead: head, minCylinder: min, maxCylinder: max, direction };
      for (const r of runAllAlgorithms(input)) {
        const label = `${r.algorithm} ${direction} ${JSON.stringify(input)}`;
        assert.equal(r.path[0], head, label);
        assert.ok(r.path.every((c) => c >= min && c <= max), `path in range: ${label}`);
        assert.equal(r.totalMovement, r.distances.reduce((a, b) => a + b, 0), label);
        assert.equal(r.totalMovement, r.path.slice(1).reduce((s, c, i) => s + Math.abs(c - r.path[i]), 0), label);
        assert.deepEqual([...r.serviceSequence].sort((a, b) => a - b), [...requests].sort((a, b) => a - b), label);
        assert.equal(r.averageMovement, r.totalMovement / requests.length, label);
      }
    }
  }
});

// ---------------------------------------------------------------- validation
const goodForm = { queue: '98, 183, 37', head: '53', min: '0', max: '199', direction: 'right' };

test('validation accepts the example input', () => {
  const v = validateInput(goodForm);
  assert.equal(v.valid, true);
  assert.deepEqual(v.values.requests, [98, 183, 37]);
});

test('validation rejects empty queue, bad numbers and out-of-range values', () => {
  assert.ok(validateInput({ ...goodForm, queue: '   ' }).errors.queue);
  assert.match(validateInput({ ...goodForm, queue: '10, abc, 12.5' }).errors.queue, /abc, 12\.5/);
  assert.match(validateInput({ ...goodForm, queue: '10, 250, -3' }).errors.queue, /250, -3/);
  assert.ok(validateInput({ ...goodForm, head: '500' }).errors.head);
  assert.ok(validateInput({ ...goodForm, head: '' }).errors.head);
  assert.ok(validateInput({ ...goodForm, min: '200' }).errors.max);
  assert.ok(validateInput({ ...goodForm, max: 'x' }).errors.max);
  assert.equal(validateInput({ ...goodForm, queue: '1, 2, 3' , max: '1'}).valid, false);
});
