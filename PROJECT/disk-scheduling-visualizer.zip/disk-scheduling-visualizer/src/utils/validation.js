/**
 * Form validation. Returns friendly messages instead of throwing.
 *
 * The form stores everything as text; this module converts it to numbers
 * and reports exactly what is wrong (nothing is silently discarded).
 */

const INTEGER_PATTERN = /^[+-]?\d+$/;
export const MAX_REQUESTS = 60;

/** Parse a whole number from text. Returns null if the text is not a valid integer. */
function parseInteger(text) {
  const trimmed = String(text ?? '').trim();
  if (!INTEGER_PATTERN.test(trimmed)) return null;
  const value = Number(trimmed);
  return Number.isSafeInteger(value) ? value : null;
}

/** Show at most a few offending values in a message. */
function preview(list, limit = 6) {
  const shown = list.slice(0, limit).join(', ');
  return list.length > limit ? `${shown}, … (+${list.length - limit} more)` : shown;
}

/**
 * @param {{queue:string, head:string, min:string, max:string, direction:string}} form
 * @returns {{valid:boolean, errors:object, values:object|null}}
 */
export function validateInput(form) {
  const errors = {};

  // ---- Cylinder range -------------------------------------------------
  const minValue = parseInteger(form.min);
  const maxValue = parseInteger(form.max);

  if (String(form.min).trim() === '') errors.min = 'Minimum cylinder is required.';
  else if (minValue === null) errors.min = 'Minimum cylinder must be a whole number (for example 0).';

  if (String(form.max).trim() === '') errors.max = 'Maximum cylinder is required.';
  else if (maxValue === null) errors.max = 'Maximum cylinder must be a whole number (for example 199).';

  let rangeOk = minValue !== null && maxValue !== null;
  if (rangeOk && minValue >= maxValue) {
    errors.max = 'Maximum cylinder must be greater than the minimum cylinder.';
    rangeOk = false;
  }

  // ---- Initial head ---------------------------------------------------
  const headValue = parseInteger(form.head);
  if (String(form.head).trim() === '') {
    errors.head = 'Initial head position is required.';
  } else if (headValue === null) {
    errors.head = 'Initial head position must be a whole number (for example 53).';
  } else if (rangeOk && (headValue < minValue || headValue > maxValue)) {
    errors.head = `Initial head must be between ${minValue} and ${maxValue}.`;
  }

  // ---- Request queue --------------------------------------------------
  const queueText = String(form.queue ?? '').trim();
  let requests = [];
  if (queueText === '') {
    errors.queue = 'Enter at least one cylinder request, separated by commas.';
  } else {
    const tokens = queueText.split(/[\s,;]+/).filter(Boolean);
    const parsed = tokens.map((token) => ({ token, value: parseInteger(token) }));
    const invalid = parsed.filter((p) => p.value === null).map((p) => p.token);

    if (invalid.length > 0) {
      errors.queue = `Invalid value${invalid.length > 1 ? 's' : ''}: ${preview(
        invalid,
      )}. Use whole numbers separated by commas.`;
    } else if (parsed.length > MAX_REQUESTS) {
      errors.queue = `Too many requests (${parsed.length}). Please use at most ${MAX_REQUESTS}.`;
    } else {
      requests = parsed.map((p) => p.value);
      if (rangeOk) {
        const outOfRange = requests.filter((r) => r < minValue || r > maxValue);
        if (outOfRange.length > 0) {
          errors.queue = `Out of range (${minValue}–${maxValue}): ${preview(outOfRange)}.`;
        }
      }
    }
  }

  const valid = Object.keys(errors).length === 0;
  return {
    valid,
    errors,
    values: valid
      ? {
          requests,
          initialHead: headValue,
          minCylinder: minValue,
          maxCylinder: maxValue,
          direction: form.direction === 'left' ? 'left' : 'right',
        }
      : null,
  };
}
