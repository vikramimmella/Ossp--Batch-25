import { useState } from 'react';
import Header from './components/Header.jsx';
import InputForm from './components/InputForm.jsx';
import DiskVisualization from './components/DiskVisualization.jsx';
import ResultsPanel from './components/ResultsPanel.jsx';
import ComparisonTable from './components/ComparisonTable.jsx';
import ComparisonChart from './components/ComparisonChart.jsx';
import LearnSection from './components/LearnSection.jsx';
import { runAlgorithm, runAllAlgorithms } from './algorithms/index.js';
import { validateInput } from './utils/validation.js';
import { useAnimation } from './hooks/useAnimation.js';

// Sample input from the project brief.
const EXAMPLE = {
  queue: '98, 183, 37, 122, 14, 124, 65, 67',
  head: '53',
  min: '0',
  max: '199',
  direction: 'right',
};
const DEFAULT_FORM = { ...EXAMPLE, algorithm: 'fcfs' };

/** Text snapshot of the inputs, used to tell when results are out of date. */
const inputSignature = (form) =>
  [form.queue.trim(), form.head.trim(), form.min.trim(), form.max.trim(), form.direction].join('|');

export default function App() {
  const [form, setForm] = useState(DEFAULT_FORM);
  const [errors, setErrors] = useState({});
  const [result, setResult] = useState(null);
  const [resultSignature, setResultSignature] = useState('');
  const [comparison, setComparison] = useState(null); // { results, signature, input }
  const [speed, setSpeed] = useState(900);

  const total = result ? result.steps.length : 0;
  // `result` is the reset key: a new simulation restarts the animation.
  const animation = useAnimation(total, result, speed);

  const handleChange = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  };

  const scrollToId = (id) => {
    requestAnimationFrame(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  };

  const handleRun = () => {
    const validation = validateInput(form);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }
    setErrors({});
    setResult(runAlgorithm(form.algorithm, validation.values)); // new object => animation resets
    setResultSignature(`${inputSignature(form)}|${form.algorithm}`);
    // On narrow screens the diagram is below the form, so bring it into view.
    if (window.matchMedia('(max-width: 1023px)').matches) scrollToId('visualization');
  };

  const handleCompare = () => {
    const validation = validateInput(form);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }
    setErrors({});
    setComparison({
      results: runAllAlgorithms(validation.values),
      signature: inputSignature(form),
      input: validation.values,
    });
    scrollToId('comparison');
  };

  const handleExample = () => {
    setForm((current) => ({ ...current, ...EXAMPLE }));
    setErrors({});
  };

  const handleReset = () => {
    setForm(DEFAULT_FORM);
    setErrors({});
    setResult(null);
    setResultSignature('');
    setComparison(null);
  };

  const resultStale = result !== null && resultSignature !== `${inputSignature(form)}|${form.algorithm}`;
  const comparisonStale = comparison !== null && comparison.signature !== inputSignature(form);

  const controls = {
    stepIndex: animation.stepIndex,
    playing: animation.playing,
    speed,
    onPlay: animation.play,
    onPause: animation.pause,
    onNext: animation.next,
    onPrev: animation.prev,
    onRestart: animation.restart,
    onSpeedChange: setSpeed,
  };

  return (
    <div id="top">
      <Header />

      <main>
        <section className="hero">
          <div className="container">
            <span className="badge badge-blue">Operating Systems Project</span>
            <h1>Disk Scheduling Algorithm Visualizer</h1>
            <p className="hero-sub">
              Simulate and compare FCFS, SSTF, SCAN and C-SCAN interactively. Enter a request queue,
              watch the disk head move step by step, and see exactly how each seek distance is
              calculated.
            </p>
          </div>
        </section>

        <section id="simulator" className="section">
          <div className="container">
            <div className="section-head">
              <h2>Simulator</h2>
              <p>Configure the input, run an algorithm and animate the head movement.</p>
            </div>

            <div className="sim-grid">
              <InputForm
                form={form}
                errors={errors}
                onChange={handleChange}
                onRun={handleRun}
                onCompare={handleCompare}
                onExample={handleExample}
                onReset={handleReset}
              />
              <div id="visualization">
                <DiskVisualization result={result} controls={controls} />
              </div>
            </div>

            <div className="results-wrap">
              <ResultsPanel result={result} stepIndex={animation.stepIndex} stale={resultStale} />
            </div>
          </div>
        </section>

        <section id="comparison" className="section section-tint">
          <div className="container">
            <div className="section-head">
              <h2>Algorithm comparison</h2>
              <p>
                Press <strong>Compare All</strong> to run all four algorithms on the same input.
              </p>
            </div>

            {comparison ? (
              <div className="card compare-card">
                <p className="card-sub">
                  Head {comparison.input.initialHead} · cylinders {comparison.input.minCylinder}–
                  {comparison.input.maxCylinder} · SCAN / C-SCAN direction {comparison.input.direction} ·{' '}
                  {comparison.input.requests.length} requests
                </p>
                {comparisonStale && (
                  <div className="notice" role="status">
                    The inputs have changed since this comparison. Press Compare All to update it.
                  </div>
                )}
                <ComparisonChart results={comparison.results} />
                <ComparisonTable results={comparison.results} />
                <p className="note">
                  Which algorithm has the lowest movement depends on the request queue, the initial
                  head position and the starting direction. A lower total seek distance does not make
                  an algorithm the best choice in every practical situation: fairness, starvation and
                  waiting-time variance matter too.
                </p>
              </div>
            ) : (
              <div className="card empty-card">
                <p>
                  No comparison yet. Check the input above, then press <strong>Compare All</strong>.
                </p>
              </div>
            )}
          </div>
        </section>

        <section id="learn" className="section">
          <div className="container">
            <div className="section-head">
              <h2>Learn Disk Scheduling</h2>
              <p>A short revision guide for the four algorithms.</p>
            </div>
            <LearnSection />
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container">
          Disk Scheduling Algorithm Visualizer · Operating Systems and System Programming (OSSP) project
        </div>
      </footer>
    </div>
  );
}
