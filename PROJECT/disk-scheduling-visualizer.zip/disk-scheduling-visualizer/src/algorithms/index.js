import { fcfs } from './fcfs.js';
import { sstf } from './sstf.js';
import { scan } from './scan.js';
import { cscan } from './cscan.js';

/** Registry used by the UI (selector buttons, comparison table, chart). */
export const ALGORITHMS = [
  { key: 'fcfs', label: 'FCFS', fullName: 'First Come, First Served', run: fcfs },
  { key: 'sstf', label: 'SSTF', fullName: 'Shortest Seek Time First', run: sstf },
  { key: 'scan', label: 'SCAN', fullName: 'SCAN (Elevator Algorithm)', run: scan },
  { key: 'cscan', label: 'C-SCAN', fullName: 'Circular SCAN', run: cscan },
];

/**
 * Run one algorithm.
 * @param {string} key    'fcfs' | 'sstf' | 'scan' | 'cscan'
 * @param {object} input  { requests, initialHead, direction, minCylinder, maxCylinder }
 */
export function runAlgorithm(key, input) {
  const algorithm = ALGORITHMS.find((a) => a.key === key);
  if (!algorithm) throw new Error(`Unknown algorithm: ${key}`);
  return algorithm.run(input);
}

/** Run all four algorithms on identical input. */
export function runAllAlgorithms(input) {
  return ALGORITHMS.map((a) => a.run(input));
}

export { fcfs, sstf, scan, cscan };
