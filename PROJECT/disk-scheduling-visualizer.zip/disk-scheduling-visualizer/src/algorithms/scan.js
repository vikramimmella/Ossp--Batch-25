import { buildResult, partitionRequests, STEP_KIND } from './common.js';

/**
 * SCAN - the "elevator" algorithm.
 *
 * 1. Move in the chosen direction, servicing requests on the way.
 * 2. Continue to the physical end of the disk (the boundary).
 * 3. Reverse and service the remaining requests, stopping at the last one.
 *
 * The trip to the boundary is part of the head path and is counted in the
 * total head movement.
 */
export function scan(input) {
  const { requests, initialHead, direction, minCylinder, maxCylinder } = input;
  const goingRight = direction !== 'left';
  const boundary = goingRight ? maxCylinder : minCylinder;

  const { ahead, behind } = partitionRequests(requests, initialHead, direction);
  // After reversing, the head travels back towards the head's start side:
  //   going right first -> come back moving left  (descending order)
  //   going left first  -> come back moving right (ascending order)
  const returning = goingRight ? [...behind].reverse() : behind;

  const moves = [];
  ahead.forEach((cylinder) => moves.push({ to: cylinder, kind: STEP_KIND.SERVICE }));

  // Travel to the boundary unless the head is already sitting on it.
  const reached = ahead.length > 0 ? ahead[ahead.length - 1] : initialHead;
  if (reached !== boundary) moves.push({ to: boundary, kind: STEP_KIND.BOUNDARY });

  returning.forEach((cylinder) => moves.push({ to: cylinder, kind: STEP_KIND.SERVICE }));

  return buildResult({ key: 'scan', algorithm: 'SCAN', input, moves });
}
