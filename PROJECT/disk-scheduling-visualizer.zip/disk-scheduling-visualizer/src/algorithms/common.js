/**
 * Shared helpers for all disk scheduling algorithms.
 *
 * Every algorithm only has to describe its head movement as a list of "moves":
 *     { to: <cylinder>, kind: 'service' | 'boundary' | 'wrap' }
 * buildResult() then derives every number (distances, total, average, path)
 * from those moves, so the maths lives in exactly one place.
 *
 * Move kinds
 *   service  - the head arrives at a cylinder that has a pending request
 *   boundary - SCAN / C-SCAN travel to the physical end of the disk
 *   wrap     - C-SCAN jumps from one end of the disk to the other end
 */

export const STEP_KIND = {
  SERVICE: 'service',
  BOUNDARY: 'boundary',
  WRAP: 'wrap',
};

/**
 * Turn a list of moves into the standard simulation result object.
 *
 * @param {object} args
 * @param {string} args.key        short id, e.g. 'fcfs'
 * @param {string} args.algorithm  display name, e.g. 'FCFS'
 * @param {object} args.input      { requests, initialHead, direction, minCylinder, maxCylinder }
 * @param {Array}  args.moves      ordered list of { to, kind }
 */
export function buildResult({ key, algorithm, input, moves }) {
  const { requests, initialHead, direction, minCylinder, maxCylinder } = input;

  // Walk through the moves, computing |to - from| for each one.
  let current = initialHead;
  const steps = moves.map((move, i) => {
    const distance = Math.abs(move.to - current);
    const step = { index: i + 1, from: current, to: move.to, distance, kind: move.kind };
    current = move.to;
    return step;
  });

  const distances = steps.map((s) => s.distance);
  const totalMovement = distances.reduce((sum, d) => sum + d, 0);

  // The order requests were actually serviced (excludes boundary / wrap moves).
  const serviceSequence = steps.filter((s) => s.kind === STEP_KIND.SERVICE).map((s) => s.to);
  const requestsServiced = serviceSequence.length;

  return {
    key,
    algorithm,
    initialHead,
    direction,
    minCylinder,
    maxCylinder,
    requests: [...requests], // original input order
    serviceSequence, // order requests were serviced
    path: [initialHead, ...steps.map((s) => s.to)], // full physical head path
    steps, // detailed list: { index, from, to, distance, kind }
    distances, // individual movement distances
    totalMovement,
    // Average = total movement / number of real requests serviced
    averageMovement: requestsServiced > 0 ? totalMovement / requestsServiced : 0,
    requestsServiced,
  };
}

/**
 * Split requests around the head for SCAN-style algorithms.
 *
 *  ahead  - requests the head meets while travelling in `direction`,
 *           already in travel order (nearest first).
 *  behind - requests on the other side of the head, sorted ascending.
 *
 * A request exactly at the head position counts as "ahead" (distance 0).
 */
export function partitionRequests(requests, head, direction) {
  const sorted = [...requests].sort((a, b) => a - b);
  if (direction === 'left') {
    return {
      ahead: sorted.filter((r) => r <= head).reverse(), // descending
      behind: sorted.filter((r) => r > head), // ascending
    };
  }
  return {
    ahead: sorted.filter((r) => r >= head), // ascending
    behind: sorted.filter((r) => r < head), // ascending
  };
}
