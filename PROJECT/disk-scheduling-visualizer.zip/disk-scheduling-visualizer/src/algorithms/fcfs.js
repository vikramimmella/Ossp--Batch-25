import { buildResult, STEP_KIND } from './common.js';

/**
 * FCFS - First Come, First Served.
 * Requests are serviced strictly in the order they arrived (input order).
 */
export function fcfs(input) {
  const moves = input.requests.map((cylinder) => ({ to: cylinder, kind: STEP_KIND.SERVICE }));
  return buildResult({ key: 'fcfs', algorithm: 'FCFS', input, moves });
}
