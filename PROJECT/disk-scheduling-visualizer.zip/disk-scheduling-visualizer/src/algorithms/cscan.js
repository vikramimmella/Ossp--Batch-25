import { buildResult, partitionRequests, STEP_KIND } from './common.js';

/**
 * C-SCAN - Circular SCAN.
 *
 * 1. Move in the chosen direction, servicing requests on the way.
 * 2. Continue to the physical end of the disk (the boundary).
 * 3. Jump ("wrap") to the opposite end of the disk without servicing anything.
 * 4. Keep moving in the SAME direction and service the remaining requests.
 *
 * Convention used in this project: the boundary trip AND the wrap-around jump
 * are both counted in total head movement. If no requests remain after the
 * boundary, the wrap-around is skipped because it would serve nothing.
 */
export function cscan(input) {
  const { requests, initialHead, direction, minCylinder, maxCylinder } = input;
  const goingRight = direction !== 'left';
  const boundary = goingRight ? maxCylinder : minCylinder;
  const wrapTarget = goingRight ? minCylinder : maxCylinder;

  const { ahead, behind } = partitionRequests(requests, initialHead, direction);
  // After the wrap the head keeps moving in the same direction:
  //   going right -> starts at min, ascending order
  //   going left  -> starts at max, descending order
  const afterWrap = goingRight ? behind : [...behind].reverse();

  const moves = [];
  ahead.forEach((cylinder) => moves.push({ to: cylinder, kind: STEP_KIND.SERVICE }));

  const reached = ahead.length > 0 ? ahead[ahead.length - 1] : initialHead;
  if (reached !== boundary) moves.push({ to: boundary, kind: STEP_KIND.BOUNDARY });

  if (afterWrap.length > 0) {
    moves.push({ to: wrapTarget, kind: STEP_KIND.WRAP });
    afterWrap.forEach((cylinder) => moves.push({ to: cylinder, kind: STEP_KIND.SERVICE }));
  }

  return buildResult({ key: 'cscan', algorithm: 'C-SCAN', input, moves });
}
