import { buildResult, STEP_KIND } from './common.js';

/**
 * SSTF - Shortest Seek Time First.
 * At every step the pending request closest to the current head is serviced.
 *
 * Tie-breaking (deterministic): if two requests are the same distance away,
 * the one on the LOWER cylinder number is chosen; if they are at the same
 * cylinder, the one that appeared earlier in the input is chosen.
 */
export function sstf(input) {
  // Keep the original position so duplicate cylinders stay in input order.
  const pending = input.requests.map((cylinder, order) => ({ cylinder, order }));
  const moves = [];
  let current = input.initialHead;

  while (pending.length > 0) {
    let bestIndex = 0;
    for (let i = 1; i < pending.length; i++) {
      const candidate = pending[i];
      const best = pending[bestIndex];
      const dCandidate = Math.abs(candidate.cylinder - current);
      const dBest = Math.abs(best.cylinder - current);
      const closer = dCandidate < dBest;
      const tieLowerCylinder = dCandidate === dBest && candidate.cylinder < best.cylinder;
      const tieEarlier =
        dCandidate === dBest && candidate.cylinder === best.cylinder && candidate.order < best.order;
      if (closer || tieLowerCylinder || tieEarlier) bestIndex = i;
    }
    // Remove the serviced request from the pending queue.
    const [chosen] = pending.splice(bestIndex, 1);
    moves.push({ to: chosen.cylinder, kind: STEP_KIND.SERVICE });
    current = chosen.cylinder;
  }

  return buildResult({ key: 'sstf', algorithm: 'SSTF', input, moves });
}
