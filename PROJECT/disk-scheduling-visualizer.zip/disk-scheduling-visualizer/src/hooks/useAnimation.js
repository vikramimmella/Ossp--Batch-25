import { useEffect, useState } from 'react';

/**
 * Step-by-step animation state for the disk head.
 *
 *   stepIndex 0           -> head is at its initial position
 *   stepIndex k (1..N)    -> head has completed the first k moves
 *
 * Only ONE interval can exist at a time: it is created by the effect while
 * `playing` is true and always cleared by the effect cleanup (pause, restart,
 * new simulation, speed change or unmount).
 *
 * @param {number} totalSteps  number of moves in the current simulation
 * @param {*}      resetKey    changes whenever a new simulation is run
 * @param {number} speedMs     delay between steps while playing
 */
export function useAnimation(totalSteps, resetKey, speedMs) {
  const [stepIndex, setStepIndex] = useState(0);
  const [playing, setPlaying] = useState(false);

  // A new simulation always starts paused at the initial head position.
  useEffect(() => {
    setStepIndex(0);
    setPlaying(false);
  }, [resetKey]);

  // The playback timer.
  useEffect(() => {
    if (!playing) return undefined;
    const timer = setInterval(() => {
      setStepIndex((index) => Math.min(index + 1, totalSteps));
    }, speedMs);
    return () => clearInterval(timer);
  }, [playing, totalSteps, speedMs]);

  // Stop automatically when the last step is reached.
  useEffect(() => {
    if (playing && stepIndex >= totalSteps) setPlaying(false);
  }, [playing, stepIndex, totalSteps]);

  const play = () => {
    if (totalSteps === 0) return;
    if (stepIndex >= totalSteps) setStepIndex(0); // replay from the start
    setPlaying(true);
  };
  const pause = () => setPlaying(false);
  const next = () => {
    setPlaying(false);
    setStepIndex((index) => Math.min(index + 1, totalSteps));
  };
  const prev = () => {
    setPlaying(false);
    setStepIndex((index) => Math.max(index - 1, 0));
  };
  const restart = () => {
    setPlaying(false);
    setStepIndex(0);
  };

  return {
    stepIndex: Math.min(stepIndex, totalSteps), // clamp while a new result is being set up
    playing,
    play,
    pause,
    next,
    prev,
    restart,
  };
}
