import { Cpu, Gauge, ListChecks, Ruler } from 'lucide-react';
import { KIND_LABEL } from './AnimationControls.jsx';

function StatCard({ icon, label, value, unit }) {
  return (
    <div className="stat">
      <span className="stat-icon" aria-hidden="true">
        {icon}
      </span>
      <div>
        <p className="stat-label">{label}</p>
        <p className="stat-value">
          {value}
          {unit && <span className="stat-unit"> {unit}</span>}
        </p>
      </div>
    </div>
  );
}

/** A row of numbers shown as small "chips". */
function ChipRow({ items, kinds }) {
  return (
    <ol className="chips">
      {items.map((value, i) => (
        <li key={i} className={`chip ${kinds ? `chip-${kinds[i]}` : ''}`}>
          {value}
        </li>
      ))}
    </ol>
  );
}

/** Result cards, queue/path summaries and the step-by-step seek calculations. */
export default function ResultsPanel({ result, stepIndex, stale }) {
  if (!result) {
    return (
      <div className="card results-empty">
        <h3>Results</h3>
        <p>
          Results appear here after you run a simulation: total head movement, the service order and
          every seek-distance calculation.
        </p>
      </div>
    );
  }

  const sumText = result.distances.join(' + ');
  const hasSpecialMoves = result.steps.some((s) => s.kind !== 'service');
  const pathKinds = ['start', ...result.steps.map((s) => s.kind)];

  return (
    <div className="card results-card">
      <div className="card-head">
        <h3>Results</h3>
        <p className="card-sub">Every value below is calculated from your input.</p>
      </div>

      {stale && (
        <div className="notice" role="status">
          The inputs have changed since this simulation. Press Run Simulation to update.
        </div>
      )}

      <div className="stats">
        <StatCard
          icon={<Ruler size={18} />}
          label="Total Head Movement"
          value={result.totalMovement}
          unit="cylinders"
        />
        <StatCard
          icon={<Gauge size={18} />}
          label="Average Movement per Request"
          value={result.averageMovement.toFixed(2)}
          unit="cylinders / request"
        />
        <StatCard
          icon={<ListChecks size={18} />}
          label="Requests Serviced"
          value={result.requestsServiced}
        />
        <StatCard icon={<Cpu size={18} />} label="Selected Algorithm" value={result.algorithm} />
      </div>

      <div className="result-blocks">
        <section>
          <h4>Original request queue</h4>
          <ChipRow items={result.requests} />
        </section>
        <section>
          <h4>Actual service order</h4>
          <ChipRow items={result.serviceSequence} />
        </section>
        <section>
          <h4>Complete head movement path</h4>
          <ChipRow items={result.path} kinds={pathKinds} />
          {hasSpecialMoves && (
            <p className="note">
              Amber = boundary visit, violet = wrap-around. These are head movements, not serviced
              requests.
            </p>
          )}
        </section>
      </div>

      <h4>Seek-distance calculations</h4>
      <div className="table-wrap">
        <table className="table calc-table">
          <thead>
            <tr>
              <th scope="col">Step</th>
              <th scope="col">Move</th>
              <th scope="col">Calculation</th>
              <th scope="col" className="num">
                Distance
              </th>
              <th scope="col">Type</th>
            </tr>
          </thead>
          <tbody>
            {result.steps.map((s) => (
              <tr key={s.index} className={s.index === stepIndex ? 'row-active' : undefined}>
                <td>{s.index}</td>
                <td>
                  {s.from} → {s.to}
                </td>
                <td className="mono">{`|${s.to} - ${s.from}| = ${s.distance}`}</td>
                <td className="num">{s.distance}</td>
                <td>
                  <span className={`badge badge-${s.kind}`}>{KIND_LABEL[s.kind]}</span>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th scope="row" colSpan={3}>
                Total head movement
              </th>
              <td className="num">{result.totalMovement}</td>
              <td />
            </tr>
          </tfoot>
        </table>
      </div>

      <p className="total-calc mono">
        Total = {sumText} = <strong>{result.totalMovement}</strong> cylinders
      </p>
      <p className="total-calc mono">
        Average = {result.totalMovement} / {result.requestsServiced} ={' '}
        <strong>{result.averageMovement.toFixed(2)}</strong> cylinders per request
      </p>
    </div>
  );
}
