import { ClipboardList, RotateCcw, Scale, Zap } from 'lucide-react';
import { ALGORITHMS } from '../algorithms/index.js';

/** Small wrapper: label + control + inline error/hint. */
function Field({ id, label, hint, error, children }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {children}
      {error ? (
        <p className="field-error" id={`${id}-error`} role="alert">
          {error}
        </p>
      ) : (
        hint && (
          <p className="field-hint" id={`${id}-hint`}>
            {hint}
          </p>
        )
      )}
    </div>
  );
}

/** Segmented control built from radio inputs (keyboard + screen-reader friendly). */
function Segmented({ name, legend, options, value, onChange, columns }) {
  return (
    <fieldset className="field segmented-field">
      <legend>{legend}</legend>
      <div className="segmented" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
        {options.map((option) => (
          <label key={option.value} className="seg">
            <input
              type="radio"
              name={name}
              value={option.value}
              checked={value === option.value}
              onChange={() => onChange(option.value)}
            />
            <span>{option.label}</span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}

export default function InputForm({ form, errors, onChange, onRun, onCompare, onExample, onReset }) {
  const errorCount = Object.values(errors).filter(Boolean).length;
  const selected = ALGORITHMS.find((a) => a.key === form.algorithm);

  const submit = (event) => {
    event.preventDefault(); // Enter key runs the selected algorithm
    onRun();
  };

  return (
    <form className="card input-card" onSubmit={submit} noValidate aria-labelledby="input-title">
      <div className="card-head">
        <h3 id="input-title">Simulation input</h3>
        <p className="card-sub">Enter a request queue and head position, then run an algorithm.</p>
      </div>

      {errorCount > 0 && (
        <div className="alert" role="alert">
          Please fix {errorCount} {errorCount === 1 ? 'issue' : 'issues'} below before running.
        </div>
      )}

      <Field
        id="queue"
        label="Disk request queue"
        hint="Cylinder numbers separated by commas, in arrival order."
        error={errors.queue}
      >
        <textarea
          id="queue"
          rows={2}
          value={form.queue}
          onChange={(e) => onChange('queue', e.target.value)}
          aria-invalid={Boolean(errors.queue)}
          aria-describedby={errors.queue ? 'queue-error' : 'queue-hint'}
          placeholder="98, 183, 37, 122, 14, 124, 65, 67"
          spellCheck="false"
        />
      </Field>

      <div className="field-row three">
        <Field id="head" label="Initial head" error={errors.head}>
          <input
            id="head"
            type="text"
            inputMode="numeric"
            value={form.head}
            onChange={(e) => onChange('head', e.target.value)}
            aria-invalid={Boolean(errors.head)}
            aria-describedby={errors.head ? 'head-error' : undefined}
          />
        </Field>
        <Field id="min" label="Min cylinder" error={errors.min}>
          <input
            id="min"
            type="text"
            inputMode="numeric"
            value={form.min}
            onChange={(e) => onChange('min', e.target.value)}
            aria-invalid={Boolean(errors.min)}
            aria-describedby={errors.min ? 'min-error' : undefined}
          />
        </Field>
        <Field id="max" label="Max cylinder" error={errors.max}>
          <input
            id="max"
            type="text"
            inputMode="numeric"
            value={form.max}
            onChange={(e) => onChange('max', e.target.value)}
            aria-invalid={Boolean(errors.max)}
            aria-describedby={errors.max ? 'max-error' : undefined}
          />
        </Field>
      </div>

      <Segmented
        name="direction"
        legend="Initial head direction"
        columns={2}
        value={form.direction}
        onChange={(value) => onChange('direction', value)}
        options={[
          { value: 'left', label: '← Left (toward min)' },
          { value: 'right', label: 'Right (toward max) →' },
        ]}
      />
      <p className="field-hint tight">Direction is used by SCAN and C-SCAN only.</p>

      <Segmented
        name="algorithm"
        legend="Algorithm"
        columns={4}
        value={form.algorithm}
        onChange={(value) => onChange('algorithm', value)}
        options={ALGORITHMS.map((a) => ({ value: a.key, label: a.label }))}
      />
      <p className="field-hint tight">{selected?.fullName}</p>

      <div className="button-grid">
        <button type="submit" className="btn btn-primary">
          <Zap size={16} aria-hidden="true" /> Run Simulation
        </button>
        <button type="button" className="btn btn-secondary" onClick={onCompare}>
          <Scale size={16} aria-hidden="true" /> Compare All
        </button>
        <button type="button" className="btn btn-ghost" onClick={onExample}>
          <ClipboardList size={16} aria-hidden="true" /> Load Example
        </button>
        <button type="button" className="btn btn-ghost" onClick={onReset}>
          <RotateCcw size={16} aria-hidden="true" /> Reset
        </button>
      </div>
    </form>
  );
}
