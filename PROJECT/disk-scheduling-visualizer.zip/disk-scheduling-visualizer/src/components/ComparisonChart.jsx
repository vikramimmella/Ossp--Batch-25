import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

const BAR = '#7ea6f5';
const BAR_LOWEST = '#1d4ed8';
const AXIS_TEXT = '#475569';

function ChartTooltip({ active, payload }) {
  if (!active || !payload || payload.length === 0) return null;
  const d = payload[0].payload;
  return (
    <div className="chart-tooltip">
      <strong>{d.name}</strong>
      <div>Total movement: {d.total} cylinders</div>
      <div>Average: {d.average} per request</div>
    </div>
  );
}

/** Bar chart of total head movement. Data comes straight from the computed results. */
export default function ComparisonChart({ results }) {
  const data = results.map((r) => ({
    name: r.algorithm,
    total: r.totalMovement,
    average: r.averageMovement.toFixed(2),
  }));
  const lowest = Math.min(...data.map((d) => d.total));

  return (
    <figure className="chart-figure">
      <div className="chart-box" role="img" aria-label="Bar chart of total head movement per algorithm">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 24, right: 16, bottom: 8, left: 8 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis
              dataKey="name"
              tick={{ fill: AXIS_TEXT, fontSize: 13 }}
              tickLine={false}
              axisLine={{ stroke: '#cbd5e1' }}
            />
            <YAxis
              allowDecimals={false}
              tick={{ fill: AXIS_TEXT, fontSize: 12 }}
              tickLine={false}
              axisLine={false}
              label={{
                value: 'Total head movement (cylinders)',
                angle: -90,
                position: 'insideLeft',
                style: { fill: AXIS_TEXT, fontSize: 12, textAnchor: 'middle' },
              }}
              width={64}
            />
            <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(37, 99, 235, 0.06)' }} />
            <Bar dataKey="total" radius={[6, 6, 0, 0]} maxBarSize={72}>
              {data.map((d) => (
                <Cell key={d.name} fill={d.total === lowest ? BAR_LOWEST : BAR} />
              ))}
              <LabelList dataKey="total" position="top" style={{ fill: '#0b1f44', fontSize: 13, fontWeight: 600 }} />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <figcaption className="chart-caption">Darker bar = lowest total head movement for this input.</figcaption>
    </figure>
  );
}
