import { useEffect, useMemo, useRef } from 'react';
import { HardDrive } from 'lucide-react';
import AnimationControls from './AnimationControls.jsx';

// ---- Drawing constants (SVG user units) -------------------------------------
const W = 760; // viewBox width
const LEFT = 56; // x of the minimum cylinder (left gutter holds step labels)
const RIGHT = 28; // right padding
const AXIS_Y = 46; // y of the cylinder axis
const FIRST_ROW = AXIS_Y + 40; // y of the start position
const ROW = 34; // vertical distance between consecutive steps

const COLORS = {
  start: '#0b1f44',
  service: '#2563eb',
  boundary: '#d97706',
  wrap: '#7c3aed',
};

/** y coordinate of step i (0 = start). Time flows downward, like a textbook diagram. */
const rowY = (i) => FIRST_ROW + i * ROW;

/** Pick readable axis ticks, always including the min and max cylinder. */
function getTicks(min, max) {
  const rough = (max - min) / 8;
  const pow = Math.pow(10, Math.floor(Math.log10(rough)));
  const f = rough / pow;
  const nice = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
  const step = Math.max(1, nice * pow);

  const ticks = [min];
  for (let t = Math.ceil((min + 1) / step) * step; t < max; t += step) {
    // avoid labels crowding the two end labels
    if (t - min >= step * 0.45 && max - t >= step * 0.45) ticks.push(t);
  }
  ticks.push(max);
  return ticks;
}

export default function DiskVisualization({ result, controls }) {
  const scrollRef = useRef(null);
  const svgRef = useRef(null);
  const { stepIndex } = controls;

  const ticks = useMemo(
    () => (result ? getTicks(result.minCylinder, result.maxCylinder) : []),
    [result],
  );

  // Keep the current row visible inside the scrollable diagram while animating.
  useEffect(() => {
    const box = scrollRef.current;
    const svg = svgRef.current;
    if (!result || !box || !svg) return;
    const scale = svg.getBoundingClientRect().width / W;
    const target = rowY(stepIndex) * scale;
    if (target < box.scrollTop + 40 || target > box.scrollTop + box.clientHeight - 40) {
      box.scrollTo({ top: Math.max(0, target - box.clientHeight / 2), behavior: 'smooth' });
    }
  }, [stepIndex, result]);

  if (!result) {
    return (
      <div className="card viz-card viz-empty">
        <span className="empty-icon" aria-hidden="true">
          <HardDrive size={26} />
        </span>
        <h3>Disk-head visualization</h3>
        <p>
          Choose an algorithm and press <strong>Run Simulation</strong> to see the head movement,
          then use Play or Next Step to animate it.
        </p>
      </div>
    );
  }

  const { minCylinder: min, maxCylinder: max } = result;
  const n = result.steps.length;
  const idx = stepIndex;

  const px = (cylinder) => LEFT + ((cylinder - min) / (max - min)) * (W - LEFT - RIGHT);

  // Points of the full head path: index 0 = start, index i = after move i.
  const points = [
    { c: result.initialHead, kind: 'start' },
    ...result.steps.map((s) => ({ c: s.to, kind: s.kind })),
  ];
  const height = rowY(n) + 32;
  const current = points[idx];

  const requestCylinders = [...new Set(result.requests)];
  const served = new Set();
  for (let i = 0; i < idx; i++) {
    if (result.steps[i].kind === 'service') served.add(result.steps[i].to);
  }

  const hasBoundary = result.steps.some((s) => s.kind === 'boundary');
  const hasWrap = result.steps.some((s) => s.kind === 'wrap');
  const showDistances = n <= 24;

  return (
    <div className="card viz-card">
      <div className="card-head">
        <h3>Disk-head movement</h3>
        <p className="card-sub">
          {result.algorithm} · head starts at {result.initialHead} · cylinders {min}–{max}
          {(result.key === 'scan' || result.key === 'cscan') &&
            ` · initial direction ${result.direction}`}
        </p>
      </div>

      <AnimationControls result={result} {...controls} />

      <div className="viz-scroll" ref={scrollRef}>
        <svg
          ref={svgRef}
          className="viz-svg"
          viewBox={`0 0 ${W} ${height}`}
          role="img"
          aria-label={`Head movement for ${result.algorithm}: ${result.path.join(', then ')}`}
        >
          <defs>
            {['service', 'boundary', 'wrap'].map((kind) => (
              <marker
                key={kind}
                id={`arrow-${kind}`}
                viewBox="0 0 10 10"
                refX="9"
                refY="5"
                markerWidth="9"
                markerHeight="9"
                markerUnits="userSpaceOnUse"
                orient="auto"
              >
                <path d="M0,1 L10,5 L0,9 z" fill={COLORS[kind]} />
              </marker>
            ))}
          </defs>

          {/* Highlight band behind the current row */}
          <g className="viz-move" style={{ transform: `translateY(${rowY(idx) - ROW / 2}px)` }}>
            <rect x="0" y="0" width={W} height={ROW} className="viz-band" />
          </g>

          {/* Guide lines for every request cylinder and the two disk ends */}
          {requestCylinders.map((c) => (
            <line
              key={`guide-${c}`}
              x1={px(c)}
              x2={px(c)}
              y1={AXIS_Y}
              y2={height - 14}
              className="viz-guide"
            />
          ))}
          <line x1={px(min)} x2={px(min)} y1={AXIS_Y} y2={height - 14} className="viz-edge" />
          <line x1={px(max)} x2={px(max)} y1={AXIS_Y} y2={height - 14} className="viz-edge" />

          {/* Cylinder axis */}
          <line x1={px(min)} x2={px(max)} y1={AXIS_Y} y2={AXIS_Y} className="viz-axis" />
          {ticks.map((t) => (
            <g key={`tick-${t}`}>
              <line x1={px(t)} x2={px(t)} y1={AXIS_Y} y2={AXIS_Y + 6} className="viz-axis" />
              <text x={px(t)} y={AXIS_Y + 20} textAnchor="middle" className="viz-tick">
                {t}
              </text>
            </g>
          ))}
          <text x="10" y={AXIS_Y + 4} className="viz-step">
            Cyl.
          </text>

          {/* Request markers on the axis: hollow = pending, filled = serviced */}
          {requestCylinders.map((c) => (
            <circle
              key={`req-${c}`}
              cx={px(c)}
              cy={AXIS_Y}
              r="4.5"
              className={served.has(c) ? 'viz-req viz-req-done' : 'viz-req'}
            />
          ))}

          {/* Movement segments with arrows. Future moves are faded. */}
          {result.steps.map((s, i) => {
            const x1 = px(points[i].c);
            const y1 = rowY(i);
            const x2 = px(points[i + 1].c);
            const y2 = rowY(i + 1);
            const dx = x2 - x1;
            const dy = y2 - y1;
            const len = Math.hypot(dx, dy); // always >= ROW, never zero
            const sx = x1 + dx * (7 / len);
            const sy = y1 + dy * (7 / len);
            const ex = x1 + dx * ((len - 9) / len);
            const ey = y1 + dy * ((len - 9) / len);
            const visited = i < idx;
            return (
              <g key={`seg-${i}`} opacity={visited ? 1 : 0.22}>
                <line
                  x1={sx}
                  y1={sy}
                  x2={ex}
                  y2={ey}
                  stroke={COLORS[s.kind]}
                  strokeWidth="2"
                  strokeDasharray={s.kind === 'wrap' ? '6 4' : undefined}
                  markerEnd={`url(#arrow-${s.kind})`}
                />
                {showDistances && visited && (
                  <text x={(x1 + x2) / 2 + 7} y={(y1 + y2) / 2 + 3} className="viz-dist">
                    {s.distance}
                  </text>
                )}
              </g>
            );
          })}

          {/* Step labels (left gutter) and position dots with cylinder numbers */}
          {points.map((p, i) => {
            const x = px(p.c);
            const y = rowY(i);
            const flip = x > W - 70; // keep labels inside the drawing near the right edge
            return (
              <g key={`pt-${i}`} opacity={i <= idx ? 1 : 0.35}>
                <text x="10" y={y + 4} className="viz-step">
                  {i === 0 ? 'Start' : `#${i}`}
                </text>
                <circle
                  cx={x}
                  cy={y}
                  r={p.kind === 'start' ? 6 : 5}
                  fill={p.kind === 'start' ? '#ffffff' : COLORS[p.kind]}
                  stroke={COLORS[p.kind]}
                  strokeWidth={p.kind === 'start' ? 3 : 0}
                />
                <text
                  x={flip ? x - 11 : x + 11}
                  y={y + 4}
                  textAnchor={flip ? 'end' : 'start'}
                  className="viz-label"
                  fill={p.kind === 'start' ? COLORS.start : COLORS[p.kind]}
                >
                  {p.c}
                </text>
              </g>
            );
          })}

          {/* Highlighted current position (ring on the path) */}
          <g
            className="viz-move"
            style={{ transform: `translate(${px(current.c)}px, ${rowY(idx)}px)` }}
          >
            <circle r="12" className="viz-current" />
          </g>

          {/* Head marker sliding along the axis */}
          <g className="viz-move" style={{ transform: `translate(${px(current.c)}px, ${AXIS_Y}px)` }}>
            <polygon points="-8,-18 8,-18 0,-5" className="viz-head" />
            <text y="-24" textAnchor="middle" className="viz-head-label">
              {current.c}
            </text>
          </g>
        </svg>
      </div>

      <ul className="legend" aria-label="Legend">
        <li>
          <span className="swatch swatch-start" /> Start position
        </li>
        <li>
          <span className="swatch swatch-service" /> Request serviced
        </li>
        <li>
          <span className="swatch swatch-req" /> Request on axis (filled when serviced)
        </li>
        {hasBoundary && (
          <li>
            <span className="swatch swatch-boundary" /> Boundary visit – head travels to the disk end
            before reversing or wrapping
          </li>
        )}
        {hasWrap && (
          <li>
            <span className="swatch swatch-wrap" /> Wrap-around – head jumps to the opposite end
            without servicing requests
          </li>
        )}
      </ul>
      <p className="note">
        Convention: boundary visits and wrap-around jumps are included in the head path and in the
        total head movement. Numbers beside arrows show seek distance.
      </p>
    </div>
  );
}
