import { BookOpen } from 'lucide-react';

const BASICS = [
  {
    title: 'What is disk scheduling?',
    text: 'Many processes issue disk I/O requests at the same time. The operating system decides the order in which they are serviced; this decision is disk scheduling.',
  },
  {
    title: 'Cylinder and disk head',
    text: 'A cylinder is the set of tracks at the same distance from the centre of the platters. The disk head sits over one cylinder at a time and must move (seek) to reach another.',
  },
  {
    title: 'Why seek distance matters',
    text: 'Moving the head is the slowest mechanical part of a disk access. Less head movement usually means lower seek time and better throughput on a mechanical disk.',
  },
  {
    title: 'FCFS vs SSTF',
    text: 'FCFS follows arrival order and ignores where the head is. SSTF always jumps to the nearest pending request, which cuts movement but can starve far-away requests.',
  },
  {
    title: 'SCAN vs C-SCAN',
    text: 'SCAN sweeps to one end, then reverses and services requests in both directions. C-SCAN services requests in one direction only, then jumps back to the other end and sweeps again.',
  },
];

const ALGORITHM_CARDS = [
  {
    short: 'FCFS',
    full: 'First Come, First Served',
    how: 'Requests are serviced strictly in the order they arrive. The head moves from one request to the next in queue order.',
    pro: 'Simple to implement and fair: no request is starved.',
    con: 'Can cause long zig-zag head movement when requests are scattered.',
    behavior: 'Total movement depends entirely on the arrival order, so it is often the highest.',
  },
  {
    short: 'SSTF',
    full: 'Shortest Seek Time First',
    how: 'From the current head position, the pending request with the smallest seek distance is chosen next.',
    pro: 'Usually much less head movement than FCFS.',
    con: 'Can starve requests far from the head when new nearby requests keep arriving.',
    behavior: 'Greedy: it stays in a local area, but is not guaranteed to give the smallest total movement.',
  },
  {
    short: 'SCAN',
    full: 'SCAN (Elevator Algorithm)',
    how: 'The head moves in one direction servicing requests until it reaches the disk end, then reverses and services requests on the way back.',
    pro: 'No starvation and a bounded waiting time; works well under heavy load.',
    con: 'Requests just behind the head wait for a full sweep; waiting time is uneven across cylinders.',
    behavior: 'Behaves like an elevator. Variants such as LOOK reverse at the last request instead of the disk end.',
  },
  {
    short: 'C-SCAN',
    full: 'Circular SCAN',
    how: 'The head services requests in one direction, reaches the end, jumps to the opposite end without servicing, and continues in the same direction.',
    pro: 'More uniform waiting time than SCAN because every cylinder is served in the same direction.',
    con: 'The return jump adds head movement that services no request.',
    behavior: 'Treats the cylinders like a circular list. Here the boundary trip and the wrap jump are both counted.',
  },
];

export default function LearnSection() {
  return (
    <div>
      <div className="card learn-intro">
        <h3>
          <BookOpen size={18} aria-hidden="true" /> Key ideas
        </h3>
        <dl className="basics">
          {BASICS.map((item) => (
            <div key={item.title} className="basic">
              <dt>{item.title}</dt>
              <dd>{item.text}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="learn-grid">
        {ALGORITHM_CARDS.map((a) => (
          <article key={a.short} className="card algo-card">
            <header>
              <span className="badge badge-blue">{a.short}</span>
              <h3>{a.full}</h3>
            </header>
            <dl>
              <dt>How it works</dt>
              <dd>{a.how}</dd>
              <dt>Advantage</dt>
              <dd>{a.pro}</dd>
              <dt>Disadvantage</dt>
              <dd>{a.con}</dd>
              <dt>Typical behavior</dt>
              <dd>{a.behavior}</dd>
            </dl>
          </article>
        ))}
      </div>

      <p className="note learn-note">
        Note: these algorithms model traditional disk scheduling for mechanical hard disks. Real
        storage systems behave differently — SSDs have no moving head, and modern drives and
        operating systems add caching, request merging and command queueing (for example NCQ) on top
        of, or instead of, these classic policies.
      </p>
    </div>
  );
}
