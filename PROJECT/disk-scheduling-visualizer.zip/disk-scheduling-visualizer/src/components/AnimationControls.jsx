import { Pause, Play, RotateCcw, SkipBack, SkipForward } from 'lucide-react';

export const KIND_LABEL = {
  service: 'Request serviced',
  boundary: 'Boundary visit',
  wrap: 'Wrap-around jump',
};

/**
 * Play / Pause / Next / Previous / Restart buttons plus a readout of the
 * current step and its seek distance.
 */
export default function AnimationControls({
  result,
  stepIndex,
  playing,
  speed,
  onPlay,
  onPause,
  onNext,
  onPrev,
  onRestart,
  onSpeedChange,
}) {
  const total = result.steps.length;
  const step = stepIndex > 0 ? result.steps[stepIndex - 1] : null;
  const progress = total > 0 ? (stepIndex / total) * 100 : 0;

  return (
    <div className="anim-controls">
      <div className="anim-buttons" role="group" aria-label="Animation controls">
        <button type="button" className="btn btn-primary btn-sm" onClick={onPlay} disabled={playing}>
          <Play size={15} aria-hidden="true" /> Play
        </button>
        <button type="button" className="btn btn-secondary btn-sm" onClick={onPause} disabled={!playing}>
          <Pause size={15} aria-hidden="true" /> Pause
        </button>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={onPrev}
          disabled={stepIndex === 0}
        >
          <SkipBack size={15} aria-hidden="true" /> Previous Step
        </button>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={onNext}
          disabled={stepIndex >= total}
        >
          Next Step <SkipForward size={15} aria-hidden="true" />
        </button>
        <button type="button" className="btn btn-ghost btn-sm" onClick={onRestart}>
          <RotateCcw size={15} aria-hidden="true" /> Restart Animation
        </button>
        <label className="speed">
          <span>Speed</span>
          <select value={speed} onChange={(e) => onSpeedChange(Number(e.target.value))}>
            <option value={1600}>Slow</option>
            <option value={900}>Normal</option>
            <option value={400}>Fast</option>
          </select>
        </label>
      </div>

      <div className="progress" aria-hidden="true">
        <div className="progress-bar" style={{ width: `${progress}%` }} />
      </div>

      {/* Not announced continuously while playing, to avoid noisy screen readers */}
      <p className="anim-readout" aria-live={playing ? 'off' : 'polite'}>
        {step ? (
          <>
            <strong>
              Step {stepIndex} of {total}
            </strong>
            : head moves {step.from} → {step.to}
            <span className="readout-sep">·</span>
            seek distance |{step.to} - {step.from}| = <strong>{step.distance}</strong>
            <span className={`badge badge-${step.kind}`}>{KIND_LABEL[step.kind]}</span>
          </>
        ) : (
          <>
            <strong>Start</strong>: head is at cylinder {result.initialHead}. Press Play or Next Step
            ({total} {total === 1 ? 'move' : 'moves'} in total).
          </>
        )}
      </p>
    </div>
  );
}
