import { Trophy } from 'lucide-react';

/** Comparison table. The algorithm(s) with the lowest total movement get a subtle highlight. */
export default function ComparisonTable({ results }) {
  const lowest = Math.min(...results.map((r) => r.totalMovement));

  return (
    <div className="table-wrap">
      <table className="table compare-table">
        <caption className="sr-only">Comparison of disk scheduling algorithms</caption>
        <thead>
          <tr>
            <th scope="col">Algorithm</th>
            <th scope="col" className="num">
              Total movement
            </th>
            <th scope="col" className="num">
              Avg / request
            </th>
            <th scope="col">Service sequence</th>
          </tr>
        </thead>
        <tbody>
          {results.map((r) => {
            const isLowest = r.totalMovement === lowest;
            return (
              <tr key={r.key} className={isLowest ? 'row-best' : undefined}>
                <th scope="row">
                  {r.algorithm}
                  {isLowest && (
                    <span className="badge badge-best">
                      <Trophy size={12} aria-hidden="true" /> Lowest
                    </span>
                  )}
                </th>
                <td className="num">{r.totalMovement}</td>
                <td className="num">{r.averageMovement.toFixed(2)}</td>
                <td className="mono seq">{r.serviceSequence.join(', ')}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
