import { HardDrive } from 'lucide-react';

const LINKS = [
  { href: '#simulator', label: 'Simulator' },
  { href: '#comparison', label: 'Comparison' },
  { href: '#learn', label: 'Learn' },
];

/** Sticky top bar: project name, "OS Project" badge and section links. */
export default function Header() {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <a className="brand" href="#top" aria-label="Disk Scheduling Visualizer – top of page">
          <span className="brand-icon" aria-hidden="true">
            <HardDrive size={18} />
          </span>
          <span className="brand-name">Disk Scheduling Visualizer</span>
          <span className="badge badge-blue">OS Project</span>
        </a>
        <nav className="nav" aria-label="Sections">
          {LINKS.map((link) => (
            <a key={link.href} href={link.href}>
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
