import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Standard Vite + React setup. The dev server usually runs on http://localhost:5173/
export default defineConfig({
  plugins: [react()],
});
