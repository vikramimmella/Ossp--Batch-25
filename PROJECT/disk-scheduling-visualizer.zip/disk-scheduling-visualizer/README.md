# Disk Scheduling Algorithm Visualizer

An interactive web application that simulates, animates and compares four classic disk scheduling algorithms: **FCFS**, **SSTF**, **SCAN** and **C-SCAN**. Built as an Operating Systems and System Programming (OSSP) project with React and Vite. Everything runs in the browser: no backend, database, login or API keys.

## Objectives

- Show how each algorithm orders disk requests and moves the disk head.
- Make seek-distance calculations visible, step by step, so they are easy to explain.
- Compare the algorithms on identical input with a table and a chart.
- Provide a short revision guide (the *Learn* section) for the four algorithms.

## Features

- Input form: request queue, initial head, min/max cylinder, initial direction, algorithm selector.
- Buttons: **Run Simulation**, **Compare All**, **Load Example**, **Reset**.
- Clear validation messages for empty input, malformed numbers, out-of-range values and invalid ranges (nothing is silently dropped).
- Animated SVG diagram of the head path with Play, Pause, Next Step, Previous Step, Restart Animation and a speed selector. Boundary visits and wrap-arounds have their own colours and legend.
- Results dashboard: total movement, average per request, requests serviced, service order, full head path, every `|to - from| = d` calculation and the total as a sum.
- Comparison table + Recharts bar chart (lowest total highlighted).
- *Learn Disk Scheduling* section with basics and four algorithm cards.
- Responsive light theme, keyboard-friendly, visible focus states, works offline after `npm install`.
- Unit tests for the algorithms and validation (`npm test`).

## Technologies

React 18 · Vite 5 · JavaScript (ES modules) · HTML5 / CSS3 · Recharts · Lucide React

## How each algorithm works

All algorithms return the same result object: `algorithm`, `initialHead`, `requests`, `serviceSequence`, `path`, `steps`, `distances`, `totalMovement`, `averageMovement`, `requestsServiced`.

| Algorithm | Rule used in this project |
|-----------|---------------------------|
| **FCFS** | Service requests in input order. Distance of each move = `abs(next - current)`. |
| **SSTF** | Always pick the pending request closest to the current head and remove it from the queue. Ties go to the **lower cylinder** (then the earlier request), so results are deterministic. |
| **SCAN** | Move in the chosen direction servicing requests, **go all the way to the disk end** (0 or max), reverse, and service the rest, stopping at the last request. |
| **C-SCAN** | Move in the chosen direction servicing requests, go to the disk end, **jump to the opposite end**, and keep moving in the **same** direction to service the rest. |

**Counting convention (shown in the UI):** the trip to the boundary and the C-SCAN wrap-around jump are part of the head path and are **included** in total movement. The average is `total movement / number of real requests`. If nothing is left to service after the boundary, C-SCAN skips the pointless wrap-around.

### Worked example (queue `98, 183, 37, 122, 14, 124, 65, 67`, head `53`, range `0–199`)

| Algorithm | Total movement | Average / request |
|-----------|---------------:|------------------:|
| FCFS | 640 | 80.00 |
| SSTF | 236 | 29.50 |
| SCAN (right) | 331 | 41.38 |
| SCAN (left) | 236 | 29.50 |
| C-SCAN (right) | 382 | 47.75 |
| C-SCAN (left) | 386 | 48.25 |

These values are checked by `npm test`. Which algorithm is lowest depends on the queue, head position and direction, and a lower seek distance is not automatically "best" in practice (fairness and starvation matter too).

## Project structure

```
disk-scheduling-visualizer/
├── package.json
├── vite.config.js
├── index.html
├── README.md
├── tests/
│   └── algorithms.test.js      # unit tests (node --test)
└── src/
    ├── main.jsx                # React entry point
    ├── App.jsx                 # page layout + application state
    ├── index.css               # all styling
    ├── algorithms/             # pure logic, no React
    │   ├── common.js           # shared result builder + request partitioning
    │   ├── fcfs.js
    │   ├── sstf.js
    │   ├── scan.js
    │   ├── cscan.js
    │   └── index.js            # registry, runAlgorithm, runAllAlgorithms
    ├── hooks/
    │   └── useAnimation.js     # step/play state with a single cleaned-up timer
    ├── utils/
    │   └── validation.js       # form validation with friendly messages
    └── components/
        ├── Header.jsx
        ├── InputForm.jsx
        ├── DiskVisualization.jsx
        ├── AnimationControls.jsx
        ├── ResultsPanel.jsx
        ├── ComparisonTable.jsx
        ├── ComparisonChart.jsx
        └── LearnSection.jsx
```

## Installation requirements (Windows)

- **Node.js** LTS (version 18 or newer) from <https://nodejs.org>. Check with `node -v` and `npm -v` in a terminal.
- **Visual Studio Code** and **Google Chrome**.
- An internet connection **only for `npm install`**. After that the app works offline.

## Run it (Windows + VS Code + Chrome)

1. Right-click the downloaded ZIP → **Extract All…** and choose a folder.
2. Open VS Code → **File → Open Folder…** → select the extracted `disk-scheduling-visualizer` folder (the one that contains `package.json`).
3. Open a terminal: **Terminal → New Terminal** (or press `` Ctrl+` ``).
4. Install dependencies (once):

   ```
   npm install
   ```

5. Start the development server:

   ```
   npm run dev
   ```

6. The terminal prints a local URL, usually **`http://localhost:5173/`**. Hold `Ctrl` and click it, or open Google Chrome and type the URL into the address bar.
7. Stop the server with `Ctrl+C` in the terminal.

**If PowerShell says "running scripts is disabled":** open the terminal dropdown (the `v` next to `+`) and choose **Command Prompt**, then run the commands again.

## Build the production version

```
npm run build
```

The optimised site is created in the `dist/` folder. To preview it locally:

```
npm run preview
```

(it prints a URL, usually `http://localhost:4173/`).

## Run the tests

```
npm test
```

## Viva notes

- Algorithm logic lives only in `src/algorithms/`; React components just display the result.
- `buildResult()` in `common.js` is the single place where distances, totals and averages are computed.
- SCAN here goes to the physical disk end. The **LOOK** / **C-LOOK** variants turn around at the last request instead; they are not implemented.
- Some textbooks do not count the C-SCAN return jump. This project counts it and says so in the interface.
- These models describe traditional mechanical disks; SSDs and modern drives with command queueing behave differently.
